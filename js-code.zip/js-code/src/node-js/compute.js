/**
 * @description 子进程，计算
 */

function getSum() {
    let sum = 0
    for (let i = 0; i < 100000000; i++) {
        sum += i
    }
    return sum
}

process.on('message', (msg) => {
    console.log('子进程 id：', process.pid)
    console.log('子进程接收到消息：', msg)
    const sum = getSum()
    process.send(sum)
})