const http = require('http')
const { fork } = require('child_process')


const server = http.createServer((req, res) => {
  if (req.url === '/get-sum') {
    console.info('主进程id:', process.pid)

    // 创建子进程
    const computeProcess = fork('./compute.js')
    computeProcess.send('计算求和')

    // 监听子进程的消息
    computeProcess.on('message', (msg) => {
      console.log('子进程返回的结果：', msg)
      res.end('sum is:' + msg)
    })

    // 异常处理
    computeProcess.on('close', () => {
      console.log('子进程已退出')
      computeProcess.kill()
      res.end('子进程已退出')
    })
  }
})

server.listen(3000, () => {
  console.log('Server is running on port 3000')
})