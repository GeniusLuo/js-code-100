/**
 * @description: 创建多个子进程，并发执行任务
 */

const http = require('http')
const cluster = require('cluster')
const numCPUs = require('os').cpus().length

if (cluster.isMaster) {
    for (let i = 0; i < numCPUs; i++) {
        cluster.fork() // 创建子进程            
    }

    cluster.on('exit', (worker, code, signal) => {
        console.log('子进程退出')   
    })
} else {
    http.createServer((req, res) => {
        res.writeHead(200, { 'Content-Type': 'text/plain' })
        res.end('Hello, world!\n')
    }).listen(3000, () => {
        console.log('Worker ' + cluster.worker.id + ' running')
    })
}