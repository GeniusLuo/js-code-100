/**
 * @description 时间复杂度
 * @date 2025-02-16
 * @return 
 */

function fn1() {
    // O(1)
    console.log('hello world');
    const obj = { a: 1 };
    console.log(obj.a);
}

function fn2() {
    // O(n)
    for (let i = 0; i < 100; i++) {
        console.log(i);
    }
}

function fn3() {
    // O(n^2)
    for (let i = 0; i < 100; i++) {
        for (let j = 0; j < 100; j++) {
            console.log(i, j);
        }
    }
}

function fn4() {
    // O(logn) 二分查找
    let i = 100;
    while (i > 0) {
        console.log(i);
        i = Math.floor(i / 2);
    }
}

function fn5() {
    // O(nlogn) for循环嵌套二分查找 
    for (let i = 0; i < 100; i++) {
        let j = 100;
        while (j > 0) {
            console.log(i, j);
            j = Math.floor(j / 2);
        }
    }
}