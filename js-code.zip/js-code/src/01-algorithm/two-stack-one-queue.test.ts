/**
 * @description 两个栈，一个队列
 * @author luochun
 * @date 2025-02-17
 */

import { TwoStackOneQueue } from './two-stack-one-queue'

// 两个栈，一个队列
// 两个栈实现一个队列，要求实现 add 和 delete 方法
describe('TwoStackOneQueue', () => {
  it('add and length', () => {
    const queue = new TwoStackOneQueue()
    expect(queue.delete()).toBe(null)
    expect(queue.length).toBe(0)
    queue.add(100)
    queue.add(200)
    queue.add(300)
    expect(queue.length).toBe(3)
    expect(queue.delete()).toBe(100)
    expect(queue.length).toBe(2)
  })
})