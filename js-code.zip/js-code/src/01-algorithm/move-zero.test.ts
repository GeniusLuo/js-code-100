/**
 * @description 单元测试：移动 0 到数组末尾
 * @test: jest src/01-algorithm/move-zero.test.ts
 */

import { moveZero2 } from './move-zero'

describe('移动 0 到数组末尾', () => {
    it('正常情况', () => {
        const arr = [1, 0, 2, 0, 3, 0, 4, 0, 5]
        moveZero2(arr)
        expect(arr).toEqual([1, 2, 3, 4, 5, 0, 0, 0, 0])
    })
    it('边界情况', () => {
        const arr = [0, 0, 0, 0, 0]
        moveZero2(arr)
        expect(arr).toEqual([0, 0, 0, 0, 0])
    })
    it('没有 0 的情况', () => {
        const arr = [1, 2, 3, 4, 5]
        moveZero2(arr)
        expect(arr).toEqual([1, 2, 3, 4, 5])
    })
    it('特殊情况', () => {
        const arr = [0, 1, 0, 2, 0, 3, 0, 4, 0, 5]
        moveZero2(arr)
        expect(arr).toEqual([1, 2, 3, 4, 5, 0, 0, 0, 0, 0])
    })
})