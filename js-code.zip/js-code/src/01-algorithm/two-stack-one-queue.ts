/**
 * @description 用两个栈实现一个队列
 */
export class TwoStackOneQueue {
  private stack1: number[] = []
  private stack2: number[] = []

  add(n: number): void {
    this.stack1.push(n)
  }

  delete(): number | null {
    let res
    const stack1 = this.stack1
    const stack2 = this.stack2
    if (stack1.length === 0) {
      return null
    }
    // 将stack1中的元素全部转移到stack2中
    while (stack1.length > 0) {
      const n = stack1.pop()
      if (n) stack2.push(n)
    }
    res = stack2.pop()
    // 将stack2中的元素全部转移到stack1中
    while (stack2.length > 0) {
      const n = stack2.pop()
      if (n) stack1.push(n)
    }
    return res || null
  }

  get length(): number {
    return this.stack1.length
  }
}

// 功能测试
const queue = new TwoStackOneQueue()
queue.add(1)
queue.add(2)
queue.add(3)
console.info(queue.length) // 3
console.info(queue.delete()) // 1
console.info(queue.length) // 2
