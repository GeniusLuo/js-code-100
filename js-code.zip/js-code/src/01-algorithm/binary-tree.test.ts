/**
 * @description 二叉搜索树单元测试
 * @test: jest src/01-algorithm/binary-tree.test.ts
 */

/** 树的结构如下：
*         5
*       /   \
*      3     7
*     / \   / \
*    2   4 6   8
*/

import { getKthValue, bst, preOrderTraverseTest, inOrderTraverse, postOrderTraverse } from './binary-tree'

// describe('二叉搜索树', () => {
//     it('正常情况', () => {
//         const res = getKthValue(bst, 3)
//         expect(res).toBe(4)
//     })

//     it('k 不在正常范围内', () => {
//         const res = getKthValue(bst, 0)
//         expect(res).toBe(null)

//         const res1 = getKthValue(bst, 1000)
//         expect(res1).toBe(null)
//     })
// })

describe('二叉树遍历', () => {
    it('前序遍历', () => {
        const result = preOrderTraverseTest()
        expect(result).toEqual([5, 3, 2, 4, 7, 6, 8])
    })

    // it('中序遍历', () => {
    //     const result: number[] = []
    //     inOrderTraverse(bst)
    //     expect(result).toEqual([2, 3, 4, 5, 6, 7, 8])
    // })

    // it('后序遍历', () => {
    //     const result: number[] = []
    //     postOrderTraverse(bst)
    //     expect(result).toEqual([2, 4, 3, 6, 8, 7, 5])
    // })
})