/**
 * @description 连续出现次数最多的字符
 */

/**
 * @description 连续出现次数最多的字符(嵌套循环) 时间复杂度O(n)
 * @param {string} str
 */

interface IResult {
    char: string
    length: number
}

export function continuousChar1(str: string): IResult {
    const res: IResult = {
        char: '',
        length: 0
    }

    const length = str.length

    if (length === 0) return res

    let tempLength = 0 // 临时记录连续出现次数

    for (let i = 0; i < length; i++) {
        tempLength = 0 // 重置临时记录连续出现次数

        for (let j = i; j < length; j++) {
            if (str[i] === str[j]) {
                tempLength++
            }

            if (str[i] !== str[j] || j === length - 1) {
                // 不相等或者到达最后一个字符
                if (tempLength > res.length) {
                    res.char = str[i]
                    res.length = tempLength
                }

                if (i < length - 1) {
                    i = j - 1
                }

                break
            }
        }
    }

    return res
}

/**
 * @description 连续出现次数最多的字符(双指针) 时间复杂度O(n)
 * @param {string} str
 */

export function continuousChar2(str: string): IResult {
    const res: IResult = {
        char: '',
        length: 0
    }

    const length = str.length
    if (length === 0) return res

    let tempLength = 0 // 临时记录连续出现次数
    let i = 0 // 右指针
    let j = 0 // 左指针
    for(; i < length; i++) {
        if (str[i] === str[j]) {
            tempLength++
        }

        if (str[i] !== str[j] || i === length - 1) {
            // 不相等或者到达最后一个字符
            if (tempLength > res.length) {
                res.char = str[j]
                res.length = tempLength
            }
            tempLength = 0
            if (i < length - 1) {
                j = i
                i-- // 回退一步
            }
        }
    }

    return res

}