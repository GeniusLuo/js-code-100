/**
 * @description 斐波那契数列单元测试
 * @test: jest src/01-algorithm/fibonacci.test.ts
 */

import { fibonacci2 } from './fibonacci'

describe('斐波那契数列', () => {
    it('0 和 1', () => {
        expect(fibonacci2(0)).toBe(0)
        expect(fibonacci2(1)).toBe(1)
    })

    it('正常情况', () => {
        expect(fibonacci2(2)).toBe(1)
        expect(fibonacci2(3)).toBe(2)
        expect(fibonacci2(4)).toBe(3)
        expect(fibonacci2(5)).toBe(5)
        expect(fibonacci2(6)).toBe(8)
        expect(fibonacci2(7)).toBe(13)
        expect(fibonacci2(8)).toBe(21)
        expect(fibonacci2(9)).toBe(34)
    })
})