/**
 * @description 将一个数据旋转k步
 * @author luochun
 * @date 2025-02-16
 */

// 将一个数据旋转k步
// 输入一个数组 [1, 2, 3, 4, 5, 6, 7] 和一个数字 k = 3
// 输出 [5, 6, 7, 1, 2, 3, 4]

/**
 * @description 旋转数组 k 步 - 使用 pop 和 unshift
 * @param {number[]} arr
 * @param {number} k 
 * @return {number[]}
 */

export function rotate1(arr: number[], k: number): number[] {
    const length = arr.length
    if (!k || length === 0) return arr
    const step = Math.abs(k % length)

    // 时间复杂度为：O(n^2) 空间复杂度为O(1)
    for (let i = 0; i < step; i++) { // O(n)
        const n = arr.pop()
        if (n) arr.unshift(n) // 数组是个有序结构（连续的内存空间），unshift 操作会非常慢 O(n)
    }
    return arr
}

/**
 * @description 旋转数组 k 步 - concat
 * @param {number[]} arr
 * @param {number} k
 * @return {number[]}
 */
export function rotate2(arr: number[], k: number): number[] {
    const length = arr.length
    if (!k || length === 0) return arr
    const step = Math.abs(k % length)

    // 时间复杂度为：O(1) 空间复杂度为O(n)
    const left = arr.slice(0, length - step) // slice 不改变原数组，所以为 O(1)
    const right = arr.slice(-step) // O(1)
    return right.concat(left) // O(1)
}