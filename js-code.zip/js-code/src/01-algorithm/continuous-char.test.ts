/**
 * @description 连续出现次数最多的字符：单元测试
 * @test jest src/01-algorithm/continuous-char.test.ts
 */

import { continuousChar1, continuousChar2 } from "./continuous-char"

describe("连续出现次数最多的字符", () => {
  it("正常情况", () => {
    const str = "aaabbbccccc"
    const res = continuousChar2(str)
    expect(res).toEqual({
      char: "c",
      length: 5
    })
  })
  it("字符串为空", () => {
    const str = ""
    const res = continuousChar2(str)
    expect(res).toEqual({
      char: '',
      length: 0
    })
  })
  it("字符串只有一个字符", () => {
    const str = "a"
    const res = continuousChar2(str)
    expect(res).toEqual({
      char: "a",
      length: 1
    })
  })
})
