/**
 * @description 斐波那契数列
 */


/**
 * @description 斐波那契数列 - 递归 - 时间复杂度 O(2^n)
 * @param {number} n
 * @returns {number}
 */
function fibonacci(n: number): number {
    if (n <= 1) {
        return n
    }

    return fibonacci(n - 1) + fibonacci(n - 2)
}

/**
 * @description 斐波那契数列 - 循环 - 时间复杂度 O(n), 数据：0, 1, 1, 2, 3, 5, 8, 13, 21, 34
 * @param {number} n
 * @returns {number}
 */

export function fibonacci2(n: number): number {
    if (n <= 0) return 0
    if (n === 1) return 1

    let n1 = 1 // 记录第 n-1 项
    let n2 = 0 // 记录第 n-2 项
    let sum = 0 // 记录第 n 项

    for(let i = 2; i<=n; i++) {
        sum = n1 + n2

        // 记录中间结果
        n2 = n1
        n1 = sum
    }
    return sum
}