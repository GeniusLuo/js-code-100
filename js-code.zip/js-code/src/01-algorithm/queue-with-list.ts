/**
 * @description 链表实现队列
 * @author luochun
 * @return 
 */

interface IListNode {
    value: number
    next: IListNode | null
}

export class MyQueue {
    // 队头
    private head: IListNode | null = null
    // 队尾
    private tail: IListNode | null = null
    // 长度
    private len: number = 0
    /**
     * 入队, 在 tail 位置
     */
    add(n: number) {
        const newNode: IListNode = {
            value: n,
            next: null
        }
        // 处理对头 head
        if(this.head === null) {
            this.head = newNode
        }
        // 处理队尾 tail
        const tailNode = this.tail
        if (tailNode) {
            tailNode.next = newNode
        }
        this.tail = newNode
        this.len++
    }
    /**
     * 出队, 在 head 位置
     */
    delete(): number | null {
        const headNode = this.head
        if (this.len === 0) return null
        if (headNode === null) return null
        
        // 取值
        const value = headNode.value
        // 处理长度
        this.head = headNode.next
        // 记录长度
        this.len--
        return value
    }
    /**
     * 获取链表长度
     */
    get length() {
        return this.len
    }
}