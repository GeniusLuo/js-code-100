/**
 * @description 移动 0 到数组末尾
 */


/**
 * @description 移动 0 到数组末尾(嵌套循环), 时间复杂度 O(n^2)
 * @param {number[]} arr
*/
export function moveZero1(arr: number[]): void {
    const length = arr.length
    if (length <= 1) return

    let zeroLength = 0
    // O(n)
    for(let i= 0; i < length - zeroLength; i++) {
        if (arr[i] === 0) {
            arr.push(0)
            // O(n)
            arr.splice(i, 1)
            i-- // 数组截取了一个元素，所以需要回退一步
            zeroLength++ // 记录 0 的个数
        }
    }
}

/**
 * @description 移动 0 到数组末尾(双指针)
 * @param {number[]} arr
 */

export function moveZero2(arr: number[]): void {
    const length = arr.length
    if (length <= 1) return

    let j = -1
    for (let i = 0; i < length; i++) {
        if (arr[i] === 0) {
            // 记录第一个 0 的位置
            if (j < 0) {
                j = i
            }
        }

        if (arr[i] !== 0 && j >= 0) {
            // 交换非 0 元素和 0 元素
            arr[j] = arr[i]
            arr[i] = 0
            j++
        }
    }
}


// 功能测试
// const arr = [1, 0, 2, 0, 3, 0, 4, 0, 5]
// moveZero1(arr) // [1, 2, 3, 4, 5, 0, 0, 0, 0]
// console.log(arr)