/**
 * @description 二叉搜索树
 */

export interface ITreeNode {
    value: number
    left: ITreeNode | null
    right: ITreeNode | null
}

const res: number[] = []

/**
 * @description 二叉树前序遍历
 * @param node tree node
 */

export function preOrderTraverse(node: ITreeNode | null) {
    if (!node) return
    // console.log(node.value)
    res.push(node.value)
    preOrderTraverse(node.left)
    preOrderTraverse(node.right)
}

export function preOrderTraverseTest() {
    preOrderTraverse(bst)
    return res
}

/**
 * @description 二叉树中序遍历
 * @param node tree node
 */

export function inOrderTraverse(node: ITreeNode | null,) {
    if (!node) return
    inOrderTraverse(node.left)
    // console.log(node.value)
    res.push(node.value)
    inOrderTraverse(node.right)
}

/**
 * @description 二叉树后序遍历
 * @param node tree node
 */

export function postOrderTraverse(node: ITreeNode | null) {
    if (!node) return
    postOrderTraverse(node.left)
    postOrderTraverse(node.right)
    // console.log(node.value)
    res.push(node.value)
}

/**
 * @description 寻找 BST 中的第 K 小的元素
 * @param node tree node    
 * @param k number
 */
export function getKthValue(node: ITreeNode, k: number): number | null {
    inOrderTraverse(node)
    console.log(111111, res)
    return res[k - 1] || null
}

/**
 * @description 二叉搜索树定义：对于树中的每个节点 X，它的左子树中的所有项的值都小于 X，而它的右子树中的所有项的值都大于 X。
 * 
 * 树的结构如下：
 * 
 *         5
 *       /   \
 *      3     7
 *     / \   / \
 *    2   4 6   8
 */
export const bst: ITreeNode = {
    value: 5,
    left: {
        value: 3,
        left: {
            value: 2,
            left: null,
            right: null
        },
        right: {
            value: 4,
            left: null,
            right: null
        }
    },
    right: {
        value: 7,
        left: {
            value: 6,
            left: null,
            right: null
        },
        right: {
            value: 8,
            left: null,
            right: null
        }
    }
}

// preOrderTraverse(bst)
// inOrderTraverse(bst)
// postOrderTraverse(bst)