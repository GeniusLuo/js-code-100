/**
 * @description 排序算法一：冒泡排序，时间复杂度O(n^2)
 * @param {number[]} arr
 */

export function bubbleSort(arr: number[]): number[] {
    const length = arr.length

    for (let i = 0; i < length; i++) {
        for (let j = 0; j < length - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                const temp = arr[j]
                arr[j] = arr[j + 1]
                arr[j + 1] = temp
            }
        }
    }

    return arr
}

/**
 * @description 排序算法二：快速排序，时间复杂度O(nlogn)
 * @param {number[]} arr
 */

export function quickSort(arr: number[]): number[] {
    // 如果数组长度小于等于1，直接返回数组（递归终止条件）
    if (arr.length <= 1) return arr

    // 选择数组中间的元素作为基准点
    const pivotIndex = Math.floor(arr.length / 2)
    // 从数组中移除基准点元素，并将其存储在 pivot 变量中
    const pivot = arr.splice(pivotIndex, 1)[0]

    // 初始化左右两个数组
    const left = []
    const right = []

    // 遍历数组中的每个元素，根据其与基准点的大小关系将其放入左数组或右数组
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] < pivot) {
            left.push(arr[i])
        } else {
            right.push(arr[i])
        }
    }

    // 递归地对左数组和右数组进行快速排序，并将结果与基准点元素拼接起来
    return quickSort(left).concat([pivot], quickSort(right))
}