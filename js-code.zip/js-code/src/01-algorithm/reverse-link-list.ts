/**
 * @description 反转单向链表
 * @author luochun
 */

/**
 * @description 根据数组生成链表
 * @param {Array} arr
 */

interface linkNode {
  value: number
  next?: linkNode
}

/**
 * @description 反转单向链表，返回新的头节点
 * @author luochun
 * @return {linkNode} newHead
 */

function reverseLinkList(head: linkNode): linkNode {
  // 定义三个指针，分别指向当前节点，前一个节点，后一个节点
  let preNode: linkNode | undefined = undefined
  let curNode: linkNode | undefined = head
  let nextNode: linkNode | undefined = head

  // 遍历链表，将当前节点的next指向前一个节点
  while (curNode) {
    nextNode = curNode.next
    curNode.next = preNode
    preNode = curNode
    curNode = nextNode
  }
  return preNode!
}

function createLinkList(arr: number[]): linkNode {
  const length = arr.length
  if (length === 0) {
    throw new Error("arr is empty")
  }

  // arr: [100, 200, 300]
  // { value: 300 }
  // { value: 200, next: { value: 300 } }
  // { value: 100, next: { value: 200, next: { value: 300 } } }

  let curNode: linkNode = {
    value: arr[length - 1]
  }
  if (length === 1) {
    return curNode
  }
  for (let i = length - 2; i >= 0; i--) {
    curNode = {
      value: arr[i],
      next: curNode
    }
  }
  return curNode
}

const arr = [100, 200, 300, 400, 500, 600]
const linkList = createLinkList(arr)
console.log(linkList)
