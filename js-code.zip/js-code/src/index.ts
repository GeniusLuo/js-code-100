import { TwoStackOneQueue } from './01-algorithm/two-stack-one-queue'

const queue = new TwoStackOneQueue()
queue.add(100)
console.log(queue.length)
